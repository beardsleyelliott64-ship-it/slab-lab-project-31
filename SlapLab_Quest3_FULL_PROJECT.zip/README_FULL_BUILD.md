# SlapLab VR — Full Quest 3 Project

Unity: 6000.0.66f2
Target: Meta Quest 3 / Android
Bundle ID: com.slaplab.quest3

Project root contains:
- Assets
- Packages
- ProjectSettings
- .github/workflows/main.yml

Gameplay:
- procedural arena
- tracked Quest left/right hands
- velocity-based slap detection
- face/body target
- score and combo
- 60-second round
- haptics
- impact particles
- synthesized impact audio
- world-space HUD

Build Automation:
- Project Subdirectory: .
- Branch: main
- Unity: 6000.0.66f2
- Builder OS: macOS Tahoe
